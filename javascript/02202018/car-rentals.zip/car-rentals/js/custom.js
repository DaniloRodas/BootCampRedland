var car1 = {
	make: 'Dodge',
	model: 'Challenger',
	year: 2014,
	mpg: 24,
	engine: 'v6'
};

function getDetails1() {
	var carName = car1.make + ' ' + car1.model;
	document.getElementById('car1MakeModel').innerHTML = carName;
}
